#include "1_1.h"
#include <stdio.h>

int main() {
  int a[graphvertices][graphvertices] = {0}; // initializing with 0's
  printf(" This program considers all edges undirected\n \n");
  while (true) {
    printf("1.Inserted edge to graph \n");
    printf("2.DFS using Recursion \n");
    printf("3.BFS using Queue \n");
    printf("3.Delete an edge \n");
    printf("Enter choice : ");
    int choice;
    scanf("%d", &choice);
    if (choice == 1) {
      int m, n;
      printf(" \n Enter two vertices the edge connects : ");
      scanf("%d %d", &m, &n);
      GraphInsertEdge(a, n, m);
    }
    if (choice == 2) {
      int j;
      printf("Enter node to start : ");
      scanf("%d", &j);
      printf("\n ");
      bool visited[graphvertices] = {false};
      GraphDFS(a, visited, j);
      printf("End of graph \n \n");
    }
  }
}
