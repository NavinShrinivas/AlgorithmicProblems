#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#define graphvertices 1000

void GraphInsertEdge(int a[][graphvertices], int n, int m); 
void GraphDFS(int a[][graphvertices], bool visited[graphvertices], int j); 
