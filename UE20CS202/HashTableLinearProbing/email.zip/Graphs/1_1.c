#include "1_1.h"

void GraphInsertEdge(int a[][graphvertices], int n, int m) {
  if (a[n][m] == 1 || a[m][n] == 1) {
    printf("\n This edge already exists! \n \n");
    return;
  } else {
    a[n][m] = 1;
    a[m][n] = 1;
    printf("\n Edge inserted to graph \n \n");
    return;
  }
}

void GraphDFS(int a[][graphvertices], bool visited[graphvertices], int j) {
  if (visited[j] == true) {
    return;
  } else {
    printf("%d ->", j);
    visited[j] = true;
    for (int i = 0; i < graphvertices; i++) {
      if (a[j][i] == 1) {
        GraphDFS(a, visited, i);
      }
    }
  }
}

void GraphBFS(int a[][graphvertices], int j) {}
